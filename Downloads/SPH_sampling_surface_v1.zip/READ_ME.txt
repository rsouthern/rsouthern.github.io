SPH Sampling--Multi-class sampling:
Paper source:
https://nccastaff.bournemouth.ac.uk/rsouthern/research/sphsampling/


The code is based on
"
Fluids v.3.1, R. Hoetzlein (c) 2012-213, http://fluids3.com
"

Requirements:
SPH sampling requires a CUDA-capable NVIDIA graphics card /w Compute capability 2.1 or higher. 
Builds tested on Windows 7 with Visual Studio 2010

Start Fluids by running SPH_sampling.exe

Fluids makes use of the following libraries:
 CUDA - http://www.nvidia.com/object/cuda_home_new.html
 OpenGL - http://www.opengl.org/
 FreeGlut - http://freeglut.sourceforge.net/
 TinyXML - http://www.grinninglizard.com/tinyxml/index.html
 Glee - http://elf-stone.com/glee.php

Keyboard commands:
------------------
0               show fours colors
1		show half sphere
2               show one color
T               re-run the sampling
O               show normal
C		Adjust camera (using mouse)
A,S,W,D 	Move camera target

